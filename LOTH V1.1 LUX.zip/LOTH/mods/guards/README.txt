=============
mod:jellyfish
=============
 This mod adds some jellyfishes without any dependencies except default.
 It is free software. It comes without any warranty,
 to the extent permitted by applicable law.
 It should run on every Minetest version.
 If there are any bugs, please tell me about.

 License:GNU Lesser General Public License

 Copyright (C) 2016 KGM: Kai Gerd Müller <kai_gerd_mueller@gmx.de>
