-- Minetest mod: creepers
-- (c) Kai Gerd Müller
-- See README.txt for licensing and other information.
--[[minetest.register_node("lotharrows:boltmodel",{
	drawtype = "nodebox",
	node_box = {type = "fixed",fixed = {{-0.5,-1/20,-1/20,0.5,1/20,1/20}}},
	tiles = {"culumalda_tree_top.png"},
	groups = {not_in_creative_inventory = 1}
})
local function setbox(self)
local v = self.object:setvelocity()
local orthogonal = vector.multiply(vector.normalize({x=-v.y,y=v.x,z = 0}),0.05)
--self.object:set_properties({})
end]]
--[[local function arrow_punch(t,a,d)
if a and a:is_player() and a:get_hp() > 0 then
t:punch(a, 1.0, {full_punch_interval=1.0,damage_groups = {fleshy=d}})
else
local arm = t:get_armor_groups()
if not arm.fleshy then
arm.fleshy = 100
end
if not arm.immortal and t and t:get_hp() > 0 then
t:set_hp(math.max(t:get_hp()-math.floor(d*arm.fleshy/100),0))
end
end
end]]
local built_in_lua_pcall = pcall
local function arrow_punch(t,a,d)
if not built_in_lua_pcall(function()
t:punch(a, 1.0, {full_punch_interval=1.0,damage_groups = {fleshy=d}})
end)then
minetest.log("action","lotharrows pcall err lotharrows init.lua ln 33")
end

end
local function do_damage(self,dtime)
	if self.lotharrow and self.damage then
	local pos = self.object:getpos()
	local target = false
	local remove = 0
	for _,entity in ipairs(minetest.get_objects_inside_radius(pos,1)) do
		local luaent  = entity:get_luaentity()
		if ((not luaent) or (not luaent.arrow_resistant))  and ((not luaent) or (not luaent.lotharrow)) then
			arrow_punch(entity,self.shooter,self.damage)
			remove  = remove-1
		elseif ((not luaent) or (not luaent.lotharrow)) then
			remove  = remove-1
		end
	end
	local n = minetest.get_node(pos).name
	if remove < 0 or (n ~= "air" and n ~= "ignore")then
--		db({"REM",tostring(remove)},"VeryImportantMessage")
		self.object:remove()
	end
	end
end
local function do_damage_firearrow(self,dtime)
	local pos = self.object:getpos()
	local target = false
	local remove = 0
	for _,entity in ipairs(minetest.get_objects_inside_radius(pos,1)) do
		local luaent  = entity:get_luaentity()
		if ((not luaent) or (not luaent.arrow_resistant))  and ((not luaent) or (not luaent.lotharrow)) then
			arrow_punch(entity,self.shooter,self.damage)
		remove  = remove-1
		elseif ((not luaent) or (not luaent.lotharrow)) then
					remove  = remove-1
		end
	end
	local n = minetest.get_node(pos).name
		if (n ~= "air" and n ~= "ignore")then
--		db({"REM",tostring(remove)},"VeryImportantMessage")

		self.object:remove()
		minetest.set_node(self.lastpos,{name = "fire:basic_flame"})
		else
		if remove < 0 then
		self.object:remove()
		minetest.set_node(pos,{name = "fire:basic_flame"})
		end
	end
	self.lastpos = pos
end
local function do_damage_black_arrow(self,dtime)
	local pos = self.object:getpos()
	local target = false
	local remove = 0
	for _,entity in ipairs(minetest.get_objects_inside_radius(pos,1)) do
		local luaent  = entity:get_luaentity()
		if ((not luaent) or (not luaent.arrow_resistant) or luaent.dragon) and ((not luaent) or (not luaent.lotharrow)) then
			arrow_punch(entity,self.shooter,self.damage)
		remove  = remove-1
		elseif ((not luaent) or (not luaent.lotharrow)) then
					remove  = remove-1
		end
	end
	local n = minetest.get_node(pos).name
	if remove < 0 or (n ~= "air" and n ~= "ignore")then
--		db({"REM",tostring(remove)},"VeryImportantMessage")
		self.object:remove()
	end
end
local function do_dragon_damage(self,dtime)
	local pos = self.object:getpos()
	local target = false
	local remove = 1
	minetest.add_particlespawner({
	amount = 100,
	time = 1,
	minpos = pos,
	maxpos = pos,
	minvel = {x=-5, y=-5, z=-5},
	maxvel = {x=5, y=5, z=5},
	minacc = {x=0, y=0, z=0},
	maxacc = {x=0, y=0, z=0},
	minexptime = 0.5,
	maxexptime = 0.5,
	minsize =5,
	maxsize = 10,
	collisiondetection = true,
	vertical = false,
	texture = "dragon_fire.png",
	})
	for _,entity in ipairs(minetest.get_objects_inside_radius(pos,2)) do
		local luaent  = entity:get_luaentity()
			if (not(luaent and luaent.dragonproof)) and ((not luaent) or (not luaent.lotharrow)) then
			arrow_punch(entity,self.shooter,self.damage)
		if entity:is_player() then
		remove  = remove-1
		local name = entity:get_player_name()
		playernutritions[name] = {0,0,0,0,0}
		update_health_data_file(name,{0,0,0,0,0})
		end
		end
	end
	local n = minetest.get_node(pos).name
	if (n ~= "air" and n ~= "ignore" and n ~= "fire:basic_flame")then
--		db({"REM",tostring(remove)},"VeryImportantMessage")
		self.object:remove()
	else
		for i = 1,12 do
		minetest.set_node(vector.add(pos,{x=math.random(2,-2),y=math.random(2,-2),z=math.random(2,-2)}),{name = "fire:basic_flame"})
		end
		--minetest.set_node(pos,{name = "fire:basic_flame"})
	end
end
	minetest.register_entity("lotharrows:arrow",{
		initial_properties = {
			--name = "arrow",
			hp_min = 1000000,
			hp_max = 1000000,
			visual_size = {x = 0.5, y = 0.5,z = 0.5},
			visual = "mesh",--"wielditem",
			mesh = "arrow.obj",
	--textures = {"lotharrows:boltmodel"},
			textures = {"steelcolor.png"},
			collisionbox = {0, 0, 0,0, 0, 0},
			physical = false
		},
		-- ON ACTIVATE --
		--on_activate = function(self)
			--[[self.]]lastpos ={x=0,y=0,z=0},--self.object:getpos(),
			--[[self.]]orc = true,
			--[[self.]]hudwel = true,
			--[[self.]]dunlending = true,
				   balrog = true,
			--[[self.]]arrow_resistant  = true,
				lotharrow = true,
			--[[self.]]shooter = nil,--self.object,
		--end,
		-- ON PUNCH --
		-- ON STEP --
		on_step = do_damage
	})
	minetest.register_entity("lotharrows:firearrow",{
		initial_properties = {
			--name = "arrow",
			hp_min = 1000000,
			hp_max = 1000000,
			visual_size = {x = 0.5, y = 0.5,z = 0.5},
			visual = "mesh",--"wielditem",
			mesh = "arrow.obj",
	--textures = {"lotharrows:boltmodel"},
			textures = {"fire_arrcolor.png"},
			collisionbox = {0, 0, 0,0, 0, 0},
			physical = false
		},
		-- ON ACTIVATE --
		--on_activate = function(self)
			--[[self.]]lastpos ={x=0,y=0,z=0},--self.object:getpos(),
			--[[self.]]orc = true,
			--[[self.]]hudwel = true,
			--[[self.]]dunlending = true,
				   balrog = true,
			--[[self.]]arrow_resistant  = true,
				lotharrow = true,
			--[[self.]]shooter = nil,--self.object,
		--end,
		-- ON PUNCH --
		-- ON STEP --
		on_activate = function(self)
			self.lastpos = self.object:getpos()
		end,
		on_step = do_damage_firearrow
	})
	minetest.register_entity("lotharrows:blackarrow",{
		initial_properties = {
			--name = "arrow",
			hp_min = 1000000,
			hp_max = 1000000,
			visual_size = {x = 0.5, y = 1,z = 0.5},
			visual = "mesh",--"wielditem",
			mesh = "arrow.obj",
	--textures = {"lotharrows:boltmodel"},
			textures = {"blackcolor.png"},
			collisionbox = {0, 0, 0,0, 0, 0},
			physical = false
		},
		-- ON ACTIVATE --
		--on_activate = function(self)
			--[[self.]]lastpos ={x=0,y=0,z=0},--self.object:getpos(),
			--[[self.]]orc = true,
			--[[self.]]hudwel = true,
			--[[self.]]dunlending = true,
			--[[self.]]arrow_resistant  = true,
				balrog = true,
				lotharrow = true,
			--[[self.]]shooter = nil,--self.object,
		--end,
		-- ON PUNCH --
		-- ON STEP --
		on_step = do_damage_black_arrow
	})
	minetest.register_entity("lotharrows:dragonfire",{
		initial_properties = {
			--name = "arrow",
			hp_min = 1000000,
			hp_max = 1000000,
			visual_size = {x = 0.5, y = 0.5,z = 0.5},
			visual = "mesh",--"wielditem",
			mesh = "arrow.obj",
	--textures = {"lotharrows:boltmodel"},
			textures = {"steelcolor.png"},
			collisionbox = {0, 0, 0,0, 0, 0},
			physical = false
		},
		-- ON ACTIVATE --
		--on_activate = function(self)
			--[[self.]]lastpos ={x=0,y=0,z=0},--self.object:getpos(),
			--[[self.]]orc = true,
			--[[self.]]hudwel = true,
			--[[self.]]dunlending = true,
				balrog = true,
				lotharrow = true,
			--[[self.]]dragonproof  = true,
			--[[self.]]shooter = nil,--self.object,
		--end,
		-- ON PUNCH --
		-- ON STEP --
		on_step = do_dragon_damage
	})
	minetest.register_entity("lotharrows:puncherhack",{
		initial_properties = {
			--name = "arrow",
			hp_min = 1000000,
			hp_max = 1000000,
			visual_size = {x = 1, y = 1,z = 1},
			visual = "cube",--"wielditem",
	--textures = {"lotharrows:boltmodel"},
			textures = {"doors_blank.png"},
			collisionbox = {0, 0, 0,0, 0, 0},
			physical = false
		},
		-- ON ACTIVATE --
		--on_activate = function(self)
			--[[self.]]lastpos ={x=0,y=0,z=0},--self.object:getpos(),
			--[[self.]]orc = true,
			--[[self.]]hudwel = true,
			--[[self.]]dunlending = true,
				   balrog = true,
			--[[self.]]arrow_resistant  = true,
				lotharrow = true,
			--[[self.]]--self.object,
				time = 1,
		--end,
		-- ON PUNCH --
		-- ON STEP --
		on_step = function(self,dtime)
			if self.time then
			self.time = self.time-dtime
			if self.time <= 0 then
			self.object:remove()
			end
			else
			self.object:remove()
			end
			end
	})
minetest.register_craftitem("lotharrows:arrow_standard",{
	description = "arrow",
	inventory_image = "arrow.png"
})
minetest.register_craftitem("lotharrows:arrow_black",{
	description = "blackarrow",
	inventory_image = "arrow.png"
})
minetest.register_craftitem("lotharrows:arrow_fire",{
	description = "firearrow",
	inventory_image = "firearrow.png"
})
function register_woodbow(woodname,uses,speed,damage,crafting_mat)
local wear = math.floor(65535/uses)
local arrstack = ItemStack("lotharrows:arrow_standard")
local blackarrstack = ItemStack("lotharrows:arrow_black")
local farrstack = ItemStack("lotharrows:arrow_fire")
minetest.register_tool("lotharrows:bow_" .. woodname, {
	description = woodname .. "bow",
	inventory_image = "bow_blackwhite.png^" .. woodname ..
			"_tree_overlay.png^bow_alphamask.png^bow_blackwhite_string.png^[makealpha:255,0,255",
	wield_scale = {x=2,y=2,z=0.25},
	range = 0,
	on_use = function(itemstack, user, pointed_thing)
			if (not user:get_inventory():remove_item("main", blackarrstack):is_empty()) then
			itemstack:add_wear(wear)
			local ld =user:get_look_dir()
			local pos = vector.add(user:getpos(),vector.multiply(ld,2))
			pos.y = pos.y + 1
			local arrow = minetest.add_entity(pos,"lotharrows:blackarrow")
			local arrowent = arrow:get_luaentity()
			arrowent.shooter = user
			arrowent.damage = damage
			arrow:setyaw(user:get_look_yaw()+math.pi/2)
			arrow:setvelocity(vector.multiply(ld,speed))
			arrow:setacceleration({x=0,y=-3,z=0})
			return itemstack
			elseif(not user:get_inventory():remove_item("main", farrstack):is_empty()) then
			itemstack:add_wear(wear)
			local ld =user:get_look_dir()
			local pos = vector.add(user:getpos(),vector.multiply(ld,2))
			pos.y = pos.y + 1
			local arrow = minetest.add_entity(pos,"lotharrows:firearrow")
			local arrowent = arrow:get_luaentity()
			arrowent.shooter = user
			arrowent.damage = damage
			arrow:setyaw(user:get_look_yaw()+math.pi/2)
			arrow:setvelocity(vector.multiply(ld,speed))
			arrow:setacceleration({x=0,y=-3,z=0})
			return itemstack
			elseif(not user:get_inventory():remove_item("main", arrstack):is_empty()) then
			itemstack:add_wear(wear)
			local ld =user:get_look_dir()
			local pos = vector.add(user:getpos(),vector.multiply(ld,2))
			pos.y = pos.y + 1
			local arrow = minetest.add_entity(pos,"lotharrows:arrow")
			local arrowent = arrow:get_luaentity()
			arrowent.shooter = user
			arrowent.damage = damage
			arrow:setyaw(user:get_look_yaw()+math.pi/2)
			arrow:setvelocity(vector.multiply(ld,speed))
			arrow:setacceleration({x=0,y=-3,z=0})
			return itemstack
			end
	end
})
local crafting_mat = crafting_mat or "default:"..woodname.."wood"
	minetest.register_craft({
	output = "lotharrows:bow_" .. woodname,
	recipe = {
		{"farming:string", crafting_mat, ''},
		{"farming:string", '', crafting_mat},
		{"farming:string", crafting_mat, ''},
	}
})
end
minetest.register_craft({
	output = "lotharrows:arrow_standard",
	recipe = {
		{"default:stick", "default:steel_ingot"}
	}
})
minetest.register_craft({
	output = "lotharrows:arrow_fire",
	recipe = {
		{"default:stick", "default:torch"}
	}
})
function register_crossbow(woodname,uses,speed,damage,crafting_mat)
local wear = math.floor(65535/uses)
local arrstack = ItemStack("lotharrows:arrow_standard")
local blackarrstack = ItemStack("lotharrows:arrow_black")
local farrstack = ItemStack("lotharrows:arrow_fire")
minetest.register_tool("lotharrows:crossbow_" .. woodname, {
	description = woodname .. "crossbow",
	inventory_image = "crossbow_blackwhite.png^default_" .. woodname ..
			"_metal_overlay.png^crossbow_alphamask.png^bow_blackwhite_string.png^[makealpha:255,0,255",
	wield_scale = {x=2,y=2,z=0.25},
	range = 0,
	on_use = function(itemstack, user, pointed_thing)
			if (not user:get_inventory():remove_item("main", blackarrstack):is_empty()) then
			itemstack:add_wear(wear)
			local ld =user:get_look_dir()
			local pos = vector.add(user:getpos(),vector.multiply(ld,2))
			pos.y = pos.y + 1
			local arrow = minetest.add_entity(pos,"lotharrows:blackarrow")
			local arrowent = arrow:get_luaentity()
			arrowent.shooter = user
			arrowent.damage = damage
			arrow:setyaw(user:get_look_yaw()+math.pi/2)
			arrow:setvelocity(vector.multiply(ld,speed))
			arrow:setacceleration({x=0,y=-1,z=0})
			return itemstack
			elseif(not user:get_inventory():remove_item("main", farrstack):is_empty()) then
			itemstack:add_wear(wear)
			local ld =user:get_look_dir()
			local pos = vector.add(user:getpos(),vector.multiply(ld,2))
			pos.y = pos.y + 1
			local arrow = minetest.add_entity(pos,"lotharrows:firearrow")
			local arrowent = arrow:get_luaentity()
			arrowent.shooter = user
			arrowent.damage = damage
			arrow:setyaw(user:get_look_yaw()+math.pi/2)
			arrow:setvelocity(vector.multiply(ld,speed))
			arrow:setacceleration({x=0,y=-1,z=0})
			return itemstack
			elseif(not user:get_inventory():remove_item("main", arrstack):is_empty()) then
			itemstack:add_wear(wear)
			local ld =user:get_look_dir()
			local pos = vector.add(user:getpos(),vector.multiply(ld,2))
			pos.y = pos.y + 1
			local arrow = minetest.add_entity(pos,"lotharrows:arrow")
			local arrowent = arrow:get_luaentity()
			arrowent.shooter = user
			arrowent.damage = damage
			arrow:setyaw(user:get_look_yaw()+math.pi/2)
			arrow:setvelocity(vector.multiply(ld,speed))
			arrow:setacceleration({x=0,y=-1,z=0})
			return itemstack
			end
	end
})
local crafting_mat = crafting_mat or "default:"..woodname.."_ingot"
	minetest.register_craft({
	output = "lotharrows:crossbow_" .. woodname,
	recipe = {
		{"farming:string", crafting_mat, ''},
		{"farming:string", '', crafting_mat},
		{"farming:string", crafting_mat, ''},
	}
})
end
--[[register_woodbow("mallorn",1000,10,7)
register_woodbow("mirk",200,18,6)
register_woodbow("jungletree",300,20,6)
register_woodbow("whitetree",800,10,10)
register_woodbow("lebethron",700,15,9)
register_woodbow("culumalda",400,12,8)
register_woodbow("normal_wood",100,8,4)
register_crossbow("steel",2000,22,7)
register_crossbow("bronze",4000,23,7)
register_crossbow("galvorn",8000,25,7)
register_crossbow("mithril",16000,26,7)]]
--[[register_woodbow("mallorn",1000,10,7)
register_woodbow("mirk",200,18,6)
register_woodbow("jungletree",300,20,6)
register_woodbow("whitetree",800,10,10)
register_woodbow("lebethron",700,15,9)
register_woodbow("culumalda",400,12,8)
register_woodbow("normal_wood",100,8,4)
register_crossbow("steel",2000,22,11)
register_crossbow("bronze",4000,23,12)
register_crossbow("galvorn",8000,25,14)
register_crossbow("mithril",16000,26,15)]]
register_woodbow("mallorn",1000,10,3)
register_woodbow("mirk",200,18,2)
register_woodbow("jungletree",300,20,2)
register_woodbow("whitetree",800,10,6)
register_woodbow("lebethron",700,15,5)
register_woodbow("culumalda",400,12,4)
register_woodbow("normal_wood",100,8,1)
register_crossbow("steel",2000,22,7)
register_crossbow("bronze",4000,23,8)
register_crossbow("galvorn",8000,25,9)
register_crossbow("mithril",16000,26,10)
--[[register_guard({
	damage = 2,
	name = "standardorc",
	drops = {"orc"},
	mesh = "character.b3d",
	textures = {"orccharacter2.png"},
	max_hp = 20,
	size = 0.9,
	speed = 3
},{"default:fangorndirt","default:brownlandsdirt","default:mordordust","default:angmarsnow"},1000)]]
--[[register_guard({
	damage = 10,
	name = "copper",
	max_hp = 40,
	size = 1,
	speed = 3
},{"default:mordordust","default:angmarsnow"},10000)
register_guard({
	damage = 11,
	name = "bronze",
	max_hp = 50,
	size = 1,
	speed = 3
},{"default:mordordust","default:angmarsnow"},10000)
register_guard({
	damage = 12,
	name = "gold",
	max_hp = 60,
	size = 1,
	speed = 3
},{"default:mordordust","default:angmarsnow"},10000)
register_guard({
	damage = 13,
	name = "mese",
	max_hp = 70,
	size = 1,
	speed = 3
},{"default:mordordust","default:angmarsnow"},10000)

register_guard({
	damage = 14,
	name = "diamond",
	max_hp = 80,
	size = 1,
	speed = 3
},{"default:mordordust","default:angmarsnow"},10000)
register_guard({
	damage = 15,
	name = "obsidian",
	max_hp = 90,
	size = 1,
	speed = 3
},{"default:mordordust","default:angmarsnow"},10000)]]


