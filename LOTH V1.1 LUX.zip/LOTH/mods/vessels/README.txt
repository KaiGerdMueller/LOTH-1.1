Minetest Game mod: vessels
==========================

Crafts
-------
Glass bottle (yields 10)

   G - G
   G - G
   - G -

Drinking Glass (yields 14)

   G - G
   G - G
   G G G

Heavy Steel Bottle (yields 5)

   S - S
   S - S
   - S -

License of source code:
-----------------------
Copyright (C) 2012 Vanessa Ezekowitz
Version 2012-09-02
Modifications by Perttu Ahola <celeron55@gmail.com>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or
(at your option) any later version.

http://www.gnu.org/licenses/lgpl-2.1.html

License of media (textures and sounds)
--------------------------------------
WTFPL

Authors of media files
-----------------------
Unless specifically noted,
Copyright (C) 2012 Vanessa Ezekowitz

