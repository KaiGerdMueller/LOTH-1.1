-- Minetest mod: creepers
-- (c) Kai Gerd Müller
-- See README.txt for licensing and other information.
local function jump_needet(size,pos)
pos.y = (pos.y-(size+0.5))
local returning = minetest.registered_nodes[minetest.get_node(pos).name].walkable
local returningz = false
for x =-1,1 do
for y =-1,1 do
returningz= returningz or minetest.registered_nodes[minetest.get_node(vector.add(pos,{x=x*0.6,y=0.5,z=y*0.6})).name].walkable
end
end
return (returning and returningz)
end
local function animate(self, t)
	if t == 1 and self.canimation ~= 1 then
		self.object:set_animation({
			x = 0,
			y = 80},
			30, 0)
		self.canimation = 1
	elseif t == 2 and self.canimation ~= 2 then
		self.object:set_animation({x = 200,y = 220},30, 0)
		self.canimation = 2
	--walkmine
	elseif t == 3 and self.canimation ~= 3 then
		self.object:set_animation({x = 168,y = 188},30, 0)
		self.canimation = 3
	--walk
	end
end
local function get_nearest_enemy(self,pos,radius,fucking_punchtest)
	local min_dist = radius+1
	local target = false
	for _,entity in ipairs(minetest.get_objects_inside_radius(pos,radius)) do
		local luaent = entity:get_luaentity()
--		db(hudwelshlaw)
		local name = entity:get_player_name()
		if (luaent and (not luaent.hudwel)) or (entity:is_player() and(
		(not hudwelshplayers[name])
		 or (hudwelshlaw[name]  and hudwelshlaw[name] > 0  )
		)) then
		local p = entity:getpos()
		local dist = vector.distance(pos,p)
				if default_do_not_punch_this_stuff(luaent) and (minetest.line_of_sight(vector.add(pos,{x=0,y=5,z=0}),vector.add(p,{x=0,y=5,z=0}), 2) == true or minetest.line_of_sight(pos,p, 2) == true --[[or minetest.line_of_sight(vector.add(pos,{x=0,y=1,z=0}),vector.add(p,{x=0,y=1,z=0}), 2) == true]]) and dist < min_dist then
			min_dist = dist
				target = entity
		end
		end
	end
if target and ((not fucking_punchtest) or minetest.line_of_sight(target:getpos(),pos,2)) then
return target
else
return false
end
end
local function get_nearest_player(self,pos,radius)
	local min_dist = radius+1
	local target = false
	for _,entity in ipairs(minetest.get_objects_inside_radius(pos,radius)) do
		if entity:is_player() then
			local p = entity:getpos()
			local dist = vector.distance(pos,p)
			if dist < min_dist then
				min_dist = dist
					target = entity
			end
		end
	end
if target then
return target:get_player_name()
else
return target
end
end
local function register_guard(def)
	--local defbox = def.size/2
	def.texture_name = def.texture_name or "dwarf"
	minetest.register_entity("guards:" .. def.name,{
		initial_properties = {
			name = def.name,
			hp_min = def.max_hp,
			hp_max = def.max_hp,
			visual_size = {x = 1, y = 0.75, z = 1},
			visual = "mesh",
			mesh = "character20.b3d",
			textures = {def.texture_name .. "shield.png^swordf.png",def.texture_name .. ".png"},
			collisionbox = {-0.4, -0.75, -0.4, 0.4, 0.75, 0.4},
			physical = true
		},
		-- ON ACTIVATE --
		on_punch = lawbreak_on_punch,
		on_activate = function(self,sdata)
			local statdata = false
			statdata = minetest.parse_json(sdata or "") or {owner_name = "",worktime = 1400}
			self.owner_name = statdata.owner_name or ""
			self.worktimer = statdata.worktime or 1400
			self.owner = minetest.get_player_by_name(self.owner_name or "")
			self.timer = 0
			self.lawname = "hudwelshlaw"
			self.hudwel = true
			self.jump = 0
			self.guard = true
			self.object:setacceleration({x=0,y=-50,z=0})
		self.object:set_animation({
			x = 0,
			y = 80},
			30, 0)
			self.canimation = 1
		end,
		-- ON PUNCH --
		-- ON STEP --
		get_staticdata = function(self)
			return minetest.write_json({owner_name = self.owner_name,worktime = self.worktimer})end,
		on_step = function(self, dtime)
			local pos = self.object:getpos()
			self.worktimer = (self.worktimer - dtime) or 1
			if self.owner then
			self.animation_set = true
			self.gravity = {x=0,y=-50,z=0}
			self.targetvektor = nil
			if self.timer < 1 then
			self.timer = self.timer+dtime
			end
			local punching = false
			if self.timer >= 1 then
				local target = get_nearest_enemy(self,pos,def.size*3,true)
				if target  then
				target:punch(self.object, 1.0, {full_punch_interval=1.0,damage_groups = {fleshy=def.damage}})
				if target:is_player() then
					add_to_law_status(target:get_player_name(),self.lawname,-def.damage)
				end
				self.timer = 0
				end
			end
			local target = get_nearest_enemy(self,pos,25)
			if target then
			target = target:getpos()
			self.targetvektor = vector.multiply(vector.normalize({x=target.x-pos.x,y=0,z=target.z-pos.z}),def.speed)
			end
			if not self.targetvektor and self.owner and self.owner:get_hp() and self.owner:get_hp()>0 then
					local pre_targetvektor = vector.subtract(self.owner:getpos(),pos)
					local pre_length = vector.length(pre_targetvektor)
					if pre_length > 4 then
						self.nextanimation = 3
						self.animation_set = false
					self.targetvektor = vector.multiply(vector.divide(pre_targetvektor,pre_length),def.speed)
					end
			end
			local velocity = self.object:getvelocity()
			self.jump = (self.jump +1)%10
			if self.targetvektor then
			if self.animation_set then
				self.nextanimation = 2
			end
			if  minetest.get_node(pos).name == "default:water_source" then
				self.gravity = {x=0,y=0,z=0}
			end
			if  minetest.get_node(vector.add(pos,{x=0,y=1,z=0})).name == "default:water_source" then
				self.targetvektor.y = 1
			end
			self.physical_v = vector.length(velocity)
			if self.jump == 0 and --[[vector.distance(vector.new(),velocity)<def.speed/10 and velocity.y == 0 and minetest.registered_nodes[minetest.get_node(vector.add(pos,{x=0,y=-(def.size+0.5),z=0})).name].walkable]]jump_needet(def.size,pos) and self.physical_v and self.physical_v < 1 then
				stomp(self,0.75)
			end
			self.object:setacceleration(self.gravity)
			self.object:setvelocity(self.targetvektor)
			self.object:setyaw(math.atan2(self.targetvektor.z,self.targetvektor.x)-math.pi/2)
			else
				self.object:setvelocity({x=0,y=0,z=0})	
				self.nextanimation = 1
			end
			if self.physical_v and self.physical_v < 0.1 then
			self.nextanimation = 1
			end
			animate(self,self.nextanimation)
			else
			self.owner = minetest.get_player_by_name(self.owner_name or "")
			--local next_owner = get_nearest_player(self,pos,100)
			--if next_owner then
			--	self.owner_name = next_owner
			--end
			end
			if self.worktimer < 0 then
				local free = minetest.add_entity(self.object:getpos(),"hudwel:dwarf")
				free:setyaw(self.object:getyaw())
				self.object:remove()
			end
			if self.object:get_hp() > 0 then return end
			self.object:remove()
		end
	})
end

--[[register_guard({
	damage = 9,
	name = "steel",
	max_hp = 30,
	size = 1,
	speed = 3
})
register_guard({
	damage = 10,
	name = "copper",
	max_hp = 40,
	size = 1,
	speed = 3
})
register_guard({
	damage = 11,
	name = "bronze",
	max_hp = 50,
	size = 1,
	speed = 3
})
register_guard({
	damage = 12,
	name = "obsidian",
	max_hp = 60,
	size = 1,
	speed = 3
})]]
register_guard({
	damage = 6,
	name = "dwarf",
	max_hp = 120,
	size = 0.75,
	texture_name = "dwarf",
	speed = 3
})

--[[register_guard({
	damage = 14,
	name = "mese",
	max_hp = 85,
	size = 1,
	speed = 3
})
register_guard({
	damage = 15,
	name = "diamond",
	max_hp = 90,
	size = 1,
	speed = 3
})]]



